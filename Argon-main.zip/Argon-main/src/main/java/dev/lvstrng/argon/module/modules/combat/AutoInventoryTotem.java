package dev.lvstrng.argon.module.modules.combat;

import dev.lvstrng.argon.event.events.TickListener;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.ModeSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.EncryptedString;
import dev.lvstrng.argon.utils.FakeInvScreen;
import dev.lvstrng.argon.utils.InventoryUtils;
import dev.lvstrng.argon.utils.TimerUtils;
import dev.lvstrng.argon.utils.PearlUtils;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import org.lwjgl.glfw.GLFW;

public final class AutoInventoryTotem extends Module implements TickListener {
	public enum Mode {
		Blatant, Random
	}

	private final ModeSetting<Mode> mode = new ModeSetting<>(EncryptedString.of("Mode"), Mode.Blatant, Mode.class)
			.setDescription(EncryptedString.of("Whether to randomize the toteming pattern or no"));
	private final NumberSetting delay = new NumberSetting(EncryptedString.of("Delay"), 0, 20, 0, 1);
	private final BooleanSetting hotbar = new BooleanSetting(EncryptedString.of("Hotbar"), true).setDescription(EncryptedString.of("Puts a totem in your hotbar as well, if enabled (Setting below will work if this is enabled)"));
	private final NumberSetting totemSlot = new NumberSetting(EncryptedString.of("Totem Slot"), 1, 9, 1, 1)
			.setDescription(EncryptedString.of("Your preferred totem slot"));
	private final BooleanSetting autoSwitch = new BooleanSetting(EncryptedString.of("Auto Switch"), false)
			.setDescription(EncryptedString.of("Switches to totem slot when going inside the inventory"));
	private final BooleanSetting forceTotem = new BooleanSetting(EncryptedString.of("Force Totem"), false).setDescription(EncryptedString.of("Puts the totem in the slot, regardless if its space is taken up by something else"));
	private final BooleanSetting autoOpen = new BooleanSetting(EncryptedString.of("Auto Open"), false)
			.setDescription(EncryptedString.of("Automatically opens and closes the inventory for you"));
	private final NumberSetting stayOpenFor = new NumberSetting(EncryptedString.of("Stay Open For"), 0, 20, 0, 1);
	private final NumberSetting triggerHealth = new NumberSetting(EncryptedString.of("Health"), 1, 20, 5, 1)
			.setDescription(EncryptedString.of("Health to trigger at. This setting will be ignored when Ignore On Ground is enabled and player is not on ground"));
	private final BooleanSetting ignoreOnGround = new BooleanSetting(EncryptedString.of("Ignore On Ground"), true)
			.setDescription(EncryptedString.of("Ignore if on ground, Trigger on throwing pearls. Better with Trigger Health"));

	int clock = -1;
	int closeClock = -1;

	TimerUtils openTimer = new TimerUtils();
	TimerUtils closeTimer = new TimerUtils();

	public AutoInventoryTotem() {
		super(EncryptedString.of("Auto Inventory Totem"),
				EncryptedString.of("Automatically equips a totem in your offhand and main hand if empty"),
				-1,
				Category.COMBAT);
		addSettings(mode, delay, hotbar, totemSlot, autoSwitch, forceTotem, autoOpen, stayOpenFor, triggerHealth, ignoreOnGround);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		clock = -1;
		closeClock = -1;
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (shouldOpenScreen() && autoOpen.getValue()){
			if (hasTotemInHotBar()) {
				if (ignoreOnGround.getValue()) {
					if (mc.player.isOnGround() && mc.player.getHealth() >= triggerHealth.getValueInt());
					else mc.setScreen(new FakeInvScreen(mc.player));
					// (not on ground) or (on ground but health is not enough): keep going
				} else {
					if (mc.player.getHealth() < triggerHealth.getValueInt()) mc.setScreen(new FakeInvScreen(mc.player));
				}
			}
			else mc.setScreen(new FakeInvScreen(mc.player));

			if (PearlUtils.isThrowingPearl()) mc.setScreen(new FakeInvScreen(mc.player));
		}

		if (!(mc.currentScreen instanceof InventoryScreen || mc.currentScreen instanceof FakeInvScreen)) {
			clock = -1;
			closeClock = -1;
			return;
		}

		if (clock == -1)
			clock = delay.getValueInt();

		if (closeClock == -1)
			closeClock = stayOpenFor.getValueInt();

		if (clock > 0)
			clock--;

		PlayerInventory inventory = mc.player.getInventory();

		if (autoSwitch.getValue())
			inventory.selectedSlot = totemSlot.getValueInt() - 1;

		if (clock <= 0) {
			if (inventory.offHand.get(0).getItem() != Items.TOTEM_OF_UNDYING) {
				int slot = mode.isMode(Mode.Blatant) ? InventoryUtils.findTotemSlot() : InventoryUtils.findRandomTotemSlot();

				if (slot != -1) {
					mc.interactionManager.clickSlot(((InventoryScreen) mc.currentScreen).getScreenHandler().syncId, slot, 40, SlotActionType.SWAP, mc.player);
					return;
				}
			}

			if(hotbar.getValue()) {
				ItemStack checkSlot = mc.player.getInventory().getStack(totemSlot.getValueInt() - 1);
				if (checkSlot.isEmpty() || forceTotem.getValue() && checkSlot.getItem() != Items.TOTEM_OF_UNDYING) {
					int slot = mode.isMode(Mode.Blatant) ? InventoryUtils.findTotemSlot() : InventoryUtils.findRandomTotemSlot();

					if (slot != -1) {
						mc.interactionManager.clickSlot(((InventoryScreen) mc.currentScreen).getScreenHandler().syncId, slot, totemSlot.getValueInt() - 1, SlotActionType.SWAP, mc.player);
						return;
					}
				}
			}


			if (shouldCloseScreen() && autoOpen.getValue()) {
				if (closeClock != 0) {
					closeClock--;
					return;
				}

				mc.currentScreen.close();
				closeClock = stayOpenFor.getValueInt();

				// Fix the issue that the player can't move after closing the inventory
				long handle = mc.getWindow().getHandle();
				if (GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_W) == GLFW.GLFW_PRESS) {
					mc.options.forwardKey.setPressed(false);
					mc.options.forwardKey.setPressed(true);
				}
				if (GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_S) == GLFW.GLFW_PRESS) {
					mc.options.backKey.setPressed(false);
					mc.options.backKey.setPressed(true);
				}
				if (GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_A) == GLFW.GLFW_PRESS) {
					mc.options.leftKey.setPressed(false);
					mc.options.leftKey.setPressed(true);
				}
				if (GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_D) == GLFW.GLFW_PRESS) {
					mc.options.rightKey.setPressed(false);
					mc.options.rightKey.setPressed(true);
				}
			}
		}
	}

	public boolean shouldCloseScreen() {
		if(hotbar.getValue())
			return (mc.player.getInventory().getStack(totemSlot.getValueInt() - 1).getItem() == Items.TOTEM_OF_UNDYING && mc.player.getOffHandStack().getItem() == Items.TOTEM_OF_UNDYING) && mc.currentScreen instanceof FakeInvScreen;
		else return ( mc.player.getOffHandStack().getItem() == Items.TOTEM_OF_UNDYING) && mc.currentScreen instanceof FakeInvScreen;
	}

	public boolean shouldOpenScreen() {
		if(hotbar.getValue())
			return (mc.player.getOffHandStack().getItem() != Items.TOTEM_OF_UNDYING || mc.player.getInventory().getStack(totemSlot.getValueInt() - 1).getItem() != Items.TOTEM_OF_UNDYING)
					&& !(mc.currentScreen instanceof FakeInvScreen) && InventoryUtils.countItemExceptHotbar(item -> item == Items.TOTEM_OF_UNDYING) != 0;
		else return (mc.player.getOffHandStack().getItem() != Items.TOTEM_OF_UNDYING && !(mc.currentScreen instanceof FakeInvScreen) && InventoryUtils.countItemExceptHotbar(item -> item == Items.TOTEM_OF_UNDYING) != 0);
	}

	public boolean hasTotemInHotBar() {
		boolean hasTotemInHotbar = false;
		for (int i = 0; i < 9; i++) {
			if (mc.player.getInventory().getStack(i).getItem() == Items.TOTEM_OF_UNDYING) {
				hasTotemInHotbar = true;
				break;
			}
		}
		return hasTotemInHotbar || mc.player.getOffHandStack().getItem() == Items.TOTEM_OF_UNDYING;
	}

	public boolean isThrowingEnderPearl() {
		if (mc.player.getMainHandStack().getItem() == Items.ENDER_PEARL || mc.player.getOffHandStack().getItem() == Items.ENDER_PEARL) {
			int useTime = mc.player.getItemUseTime();
			return useTime > 0;
		}
		
		return false;
	}
}
