package dev.lvstrng.argon.utils;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;

public class PearlUtils {
    private static boolean lastPearlCoolingDown = false;

    public static boolean isThrowingPearl(PlayerEntity player) {
        if (player == null) return false;

        float cd = player.getItemCooldownManager().getCooldownProgress(Items.ENDER_PEARL, 0);
        return cd >= 0.93f && cd <=1f;
    }

    public static boolean isThrowingPearl() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return false;
        return isThrowingPearl(mc.player);
    }
}